"""CRUD /specimens."""

from uuid import UUID

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session as DbSession

from scanner_orchestrator.api.exceptions import ConflictError, NotFoundError
from scanner_orchestrator.api.schemas.specimen import (
    SpecimenCreate, SpecimenRead, SpecimenUpdate,
)
from scanner_orchestrator.db.database import get_db
from scanner_orchestrator.db.models import Specimen
from scanner_shared.enums import SpecimenCategory

router = APIRouter(prefix="/specimens", tags=["specimens"])


@router.get("", response_model=list[SpecimenRead])
def list_specimens(
    limit:    int                    = 50,
    offset:   int                    = 0,
    category: SpecimenCategory | None = None,
    search:   str | None             = Query(default=None, description="Recherche par name"),
    db: DbSession = Depends(get_db),
):
    q = db.query(Specimen)
    if category:
        q = q.filter(Specimen.category == category)
    if search:
        q = q.filter(func.lower(Specimen.name).contains(search.lower()))
    return q.order_by(Specimen.name).offset(offset).limit(min(limit, 200)).all()


# NOTE : /search doit être déclaré AVANT /{specimen_id}
# sinon FastAPI interprète "search" comme un UUID et retourne 422.
@router.get("/search", response_model=list[SpecimenRead])
def search_specimens(
    q:        str               = Query(..., min_length=1, description="Chaîne à rechercher"),
    category: SpecimenCategory | None = None,
    limit:    int               = 10,
    db: DbSession = Depends(get_db),
):
    """
    Autocomplétion pour la modale NewSession.
    Retourne les specimens dont le name contient q, insensible à la casse.
    """
    query = db.query(Specimen).filter(
        func.lower(Specimen.name).contains(q.lower())
    )
    if category:
        query = query.filter(Specimen.category == category)
    return query.limit(min(limit, 20)).all()


@router.post("", response_model=SpecimenRead, status_code=status.HTTP_201_CREATED)
def create_specimen(payload: SpecimenCreate, db: DbSession = Depends(get_db)):
    specimen = Specimen(**payload.model_dump())
    db.add(specimen)
    try:
        db.flush()
    except IntegrityError:
        raise ConflictError("external_id déjà utilisé")
    return specimen


@router.get("/{specimen_id}", response_model=SpecimenRead)
def get_specimen(specimen_id: UUID, db: DbSession = Depends(get_db)):
    s = db.get(Specimen, specimen_id)
    if not s:
        raise NotFoundError("Specimen", specimen_id)
    return s


@router.patch("/{specimen_id}", response_model=SpecimenRead)
def update_specimen(
    specimen_id: UUID,
    payload: SpecimenUpdate,
    db: DbSession = Depends(get_db),
):
    s = db.get(Specimen, specimen_id)
    if not s:
        raise NotFoundError("Specimen", specimen_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(s, field, value)
    db.flush()
    return s


@router.delete("/{specimen_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_specimen(specimen_id: UUID, db: DbSession = Depends(get_db)):
    s = db.get(Specimen, specimen_id)
    if not s:
        raise NotFoundError("Specimen", specimen_id)
    try:
        db.delete(s)
        db.flush()
    except IntegrityError:
        raise ConflictError("Ce specimen a des sessions associées et ne peut pas être supprimé")